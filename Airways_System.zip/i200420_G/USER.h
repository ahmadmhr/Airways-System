#ifndef USER_H
#define USER_H
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Person{
	protected:
		string name;
		int id;
		string login;
		string password;
		string address;
		string cnic;
};

#endif
