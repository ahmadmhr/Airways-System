#ifndef Passenger_h
#define Passenger_h
#include "USER.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


class Passenger: public Person{ 
	public:
		void setname(string n){
			name = n;
		}
		void setid(int i){
			id = i;
		}
		void setaddress(string a){
			address = a;
		}
		void setlogin(string l){
			login = l;
		}
		void setpassword(string p){
			password = p;
		}
		void setcnic(string c){
			cnic = c;
		}
		void set_file(){
			ofstream out;
			out.open("passenger.txt",ios::app); 
			out<<name<<" "<<id<<" "<<address<<" "<<login<<" "<<password<<" "<<cnic<<""<<endl;
			out.close();
		}
};

#endif
