#ifndef Admin_h
#define Admin_h
#include "USER.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Admin: public Person{
	public:
		void setname(string n){
			name = n;
		}
		void setid(int i){
			id = i;
		}
		void setaddress(string a){
			address = a;
		}
		void setlogin(string l){
			login = l;
		}
		void setpassword(string p){
			password = p;
		}
		void set_file(){
			ofstream out;
			out.open("admin.txt",ios::app); 
			out<<name<<" "<<id<<" "<<address<<" "<<login<<" "<<password<<" "<<endl;
			out.close();
		}
};

#endif
