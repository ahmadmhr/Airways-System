#ifndef Cities_h
#define Cities_h
#include "Airport.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class cities{
	string name;
	Airport Ar[2];
	public:
		void setname(string n){
			name = n;
		}
		string return_name(){
			return name;
		}
		void setid_airport(int i,int j){
			Ar[i].setid(j);
		} 
		void set_flights(int i,int j,string type,string n_u){
			Ar[i].setflight(j-1,type,name,n_u);
		}
};

#endif
