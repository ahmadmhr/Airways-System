#ifndef Flight_h
#define Flight_h
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Flight{
	int flight_no;
	int sl;
	int seat_local;
	int sb;
	int seat_b;
	public:
		void setid(int i){
			flight_no = i;
		}
		void setseats_l_l(string city,int ai,string type,string city_d,string n_u){
			int c=0;
			int seat; 
			int s; 
			string nu;
			string ci;
			int a;
			string ty;
			string cd;
			if(flight_no == 1){
				seat=1;
				ifstream innn1;
				innn1.open("flight1.txt");
				while(!innn1.eof()){
				innn1>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn1.close();
				c=0;
				ifstream inn1;
				inn1.open("flight1.txt");
				while(!inn1.eof()){
				inn1>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++; 
				}
				} 
				inn1.close();
				if(seat == -1){
					seat = 1; 
				} 
				cout<<"local seats = "<<c<<endl; 
				if(c-1<26){
				ofstream outt1;
				outt1.open("flight1.txt",ios::app);
				outt1<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt1.close(); 
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			}
			if(flight_no == 2){ 
				seat=1;
				ifstream innn2;
				innn2.open("flight2.txt");
				while(!innn2.eof()){
				innn2>>ci>>a>>ty>>cd>>nu>>s; 
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn2.close();
				c=0;
				ifstream inn2;
				inn2.open("flight2.txt");
				while(!inn2.eof()){
				inn2>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}  
				inn2.close();
				if(seat == -1){
					seat = 1; 
				} 
				cout<<"local seats = "<<c<<endl; 
				if(c-1<26){
				ofstream outt2;
				outt2.open("flight2.txt",ios::app);
				outt2<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt2.close();
				}
				else{
					cout<<"local seats limit si full"<<endl;
				}
			}
			if(flight_no == 3){
				seat=1;
				ifstream innn3;
				innn3.open("flight3.txt");
				while(!innn3.eof()){
				innn3>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn3.close();
				c=0;
				ifstream inn3;
				inn3.open("flight3.txt");
				while(!inn3.eof()){
				inn3>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				} 
				cout<<"local seats = "<<c<<endl; 
				inn3.close();
				if(seat == -1){
					seat = 1; 
				} 
				if(c-1<26){
				ofstream outt3;
				outt3.open("flight3.txt",ios::app);
				outt3<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt3.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			} 
			if(flight_no == 4){
				seat=1;
				ifstream innn4;
				innn4.open("flight4.txt");
				while(!innn4.eof()){
				innn4>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn4.close();
				c=0;
				ifstream inn4;
				inn4.open("flight4.txt");
				while(!inn4.eof()){
				inn4>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 	
				inn4.close();
				if(seat == -1){
					seat = 1; 
				} 
				if(c-1<26){
				ofstream outt4;
				outt4.open("flight4.txt",ios::app);
				outt4<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt4.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			}
			if(flight_no == 5){
				seat=1;
				ifstream innn5;
				innn5.open("flight5.txt");
				while(!innn5.eof()){
				innn5>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn5.close(); 
				c=0;
				ifstream inn5;
				inn5.open("flight5.txt");
				while(!inn5.eof()){
				inn5>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn5.close();
				if(seat == -1){
					seat = 1; 
				} 
				if(c-1<26){
				ofstream outt5;
				outt5.open("flight5.txt",ios::app);
				outt5<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt5.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			} 
		} 
		void setseats_b_l(string city,int ai,string type,string city_d,string n_u){
			int c=0;
			int seat; 
			int s;
			string nu;
			string ci;
			int a;
			string ty;
			string cd; 
			if(flight_no == 1){
				seat=1;
				ifstream innn1;
				innn1.open("flight1.txt");
				while(!innn1.eof()){
				innn1>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn1.close();
				c=0;
				ifstream inn1;
				inn1.open("flight1.txt");
				while(!inn1.eof()){
				inn1>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn1.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt1;
				outt1.open("flight1.txt",ios::app);
				outt1<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt1.close(); 
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 2){
				seat=1;
				ifstream innn2;
				innn2.open("flight2.txt");
				while(!innn2.eof()){
				innn2>>ci>>a>>ty>>cd>>nu>>s; 
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn2.close();
				c=0;
				ifstream inn2;
				inn2.open("flight2.txt");
				while(!inn2.eof()){
				inn2>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				} 
				cout<<"Business seats = "<<c<<endl; 
				inn2.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt2;
				outt2.open("flight2.txt",ios::app);
				outt2<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt2.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 3){
				seat=1;
				ifstream innn3;
				innn3.open("flight3.txt");
				while(!innn3.eof()){
				innn3>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn3.close();
				c=0;
				ifstream inn3;
				inn3.open("flight3.txt");
				while(!inn3.eof()){
				inn3>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"Business seats = "<<c<<endl;
				inn3.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt3;
				outt3.open("flight3.txt",ios::app);
				outt3<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt3.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 4){
				seat=1;
				ifstream innn4;
				innn4.open("flight4.txt");
				while(!innn4.eof()){
				innn4>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn4.close();
				c=0;
				ifstream inn4;
				inn4.open("flight4.txt");
				while(!inn4.eof()){
				inn4>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"Business seats = "<<c<<endl;
				inn4.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt4;
				outt4.open("flight4.txt",ios::app);
				outt4<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt4.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 5){
				seat=1;
				ifstream innn5;
				innn5.open("flight5.txt");
				while(!innn5.eof()){
				innn5>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn5.close();
				c=0;
				ifstream inn5;
				inn5.open("flight5.txt");
				while(!inn5.eof()){
				inn5>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"Business seats = "<<c<<endl;
				inn5.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c<6){
				ofstream outt5;
				outt5.open("flight5.txt",ios::app);
				outt5<<city<<" "<<ai<<" "<<type<<" "<<city_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt5.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
		}   
		void setseats_l_i(string city,int ai,string type,string coun_d,string n_u){ 
			int c=0;
			string nu;
			string ci;
			int seat; 
			int s;
			int a;
			string ty;
			string cd;
			if(flight_no == 6){
				seat=1;
				ifstream innn6;
				innn6.open("flight6.txt");
				while(!innn6.eof()){
				innn6>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn6.close(); 
				c=0;
				ifstream inn6;
				inn6.open("flight6.txt");
				while(!inn6.eof()){
				inn6>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn6.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<26){
				ofstream outt6;
				outt6.open("flight6.txt",ios::app);
				outt6<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt6.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			} 
			if(flight_no == 7){
				seat=1;
				ifstream innn7;
				innn7.open("flight7.txt");
				while(!innn7.eof()){
				innn7>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn7.close(); 
				c=0;
				ifstream inn7;
				inn7.open("flight7.txt");
				while(!inn7.eof()){
				inn7>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn7.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<26){
				ofstream outt7;
				outt7.open("flight7.txt",ios::app);
				outt7<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt7.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			}
			if(flight_no == 8){
				seat=1;
				ifstream innn8;
				innn8.open("flight8.txt");
				while(!innn8.eof()){
				innn8>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn8.close(); 
				c=0;
				ifstream inn8;
				inn8.open("flight8.txt");
				while(!inn8.eof()){
				inn8>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn8.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<26){
				ofstream outt8;
				outt8.open("flight8.txt",ios::app);
				outt8<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt8.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			}
			if(flight_no == 9){
				seat=1;
				ifstream innn9;
				innn9.open("flight9.txt");
				while(!innn9.eof()){
				innn9>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn9.close();  
				c=0;
				ifstream inn9;
				inn9.open("flight9.txt");
				while(!inn9.eof()){
				inn9>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn9.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<26){
				ofstream outt9;
				outt9.open("flight9.txt",ios::app);
				outt9<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt9.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			}
			if(flight_no == 10){
				seat=1;
				ifstream innn10;
				innn10.open("flight10.txt");
				while(!innn10.eof()){
				innn10>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn10.close();  
				c=0;
				ifstream inn10;
				inn10.open("flight10.txt");
				while(!inn10.eof()){
				inn10>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn10.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<26){
				ofstream outt10;
				outt10.open("flight10.txt",ios::app);
				outt10<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt10.close();
				}
				else{
					cout<<"local seats limit is full"<<endl;
				}
			}
		} 
		void setseats_b_i(string city,int ai,string type,string coun_d,string n_u){ 
//			cout<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<flight_no;
			int c=0;
			string nu;
			string ci;
			int seat; 
			int s;
			int a;
			string ty;
			string cd;
			if(flight_no == 6){
				seat=1;
				ifstream innn6;
				innn6.open("flight6.txt");
				while(!innn6.eof()){
				innn6>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn6.close(); 
				c=0;
				ifstream inn6;
				inn6.open("flight6.txt");
				while(!inn6.eof()){
				inn6>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				} 
				}
				cout<<"local seats = "<<c<<endl; 
				inn6.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt6;
				outt6.open("flight6.txt",ios::app);
				outt6<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt6.close();
				}
				else{
					cout<<"business seats limti is full"<<endl;
				}
			}
			if(flight_no == 7){
				seat=1;
				ifstream innn7;
				innn7.open("flight7.txt");
				while(!innn7.eof()){
				innn7>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn7.close();
				c=0;
				ifstream inn7;
				inn7.open("flight7.txt");
				while(!inn7.eof()){
				inn7>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn7.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt7;
				outt7.open("flight7.txt",ios::app);
				outt7<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt7.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 8){
				seat=1;
				ifstream innn8;
				innn8.open("flight8.txt");
				while(!innn8.eof()){
				innn8>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn8.close(); 
				c=0;
				ifstream inn8;
				inn8.open("flight8.txt");
				while(!inn8.eof()){
				inn8>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn8.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt8;
				outt8.open("flight8.txt",ios::app);
				outt8<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt8.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 9){
				seat=1;
				ifstream innn9;
				innn9.open("flight9.txt");
				while(!innn9.eof()){
				innn9>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn9.close(); 
				c=0;
				ifstream inn9;
				inn9.open("flight9.txt");
				while(!inn9.eof()){
				inn9>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn9.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt9;
				outt9.open("flight9.txt",ios::app);
				outt9<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt9.close();
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			}
			if(flight_no == 10){
				seat=1;
				ifstream innn10;
				innn10.open("flight10.txt");
				while(!innn10.eof()){
				innn10>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					seat = seat+2;
				}
				} 
				seat = seat-2; 
				innn10.close();
				c=0;
				ifstream inn10;
				inn10.open("flight10.txt");
				while(!inn10.eof()){
				inn10>>ci>>a>>ty>>cd>>nu>>s;
				if(ci == city && a == ai && ty == type){
					c++;
				}
				}
				cout<<"local seats = "<<c<<endl; 
				inn10.close();
				if(seat == -1){
					seat = 1; 
				}
				if(c-1<6){
				ofstream outt10;
				outt10.open("flight10.txt",ios::app);
				outt10<<city<<" "<<ai<<" "<<type<<" "<<coun_d<<" "<<n_u<<" "<<seat<<" "<<endl;
				outt10.close(); 
				}
				else{
					cout<<"business seats limit is full"<<endl;
				}
			} 
		}
}; 

#endif
