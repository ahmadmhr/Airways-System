#ifndef Airport_h
#define Airport_h
#include "Flight.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Airport{
	int id;
	Flight F[10]; 
	public:
		void setid(int i){
			id = i;
		}
		void setflight(int i,string type,string city,string n_u){
			int l_amount = 10000;
			int l_i;
			int t_amount;
			int i_amount = 20000;
			int i_i;
			int b=0;
			int check=0;
			float time;
			string ban[3];
			ban[0] = "malaysia";
			ban[1] = "america";
			ban[2] = "spain";
			F[i].setid(i+1);
			if(i>=0 && i<5){
				string city_d;
				cout<<"Enter the name of city (destination) = ";
//				cin.ignore();
				getline(cin,city_d);
//				cout<<city<<" "<<city_d<<endl;
				if(city=="islamabad" && city_d=="lahore"){
					time = 2;
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && city_d=="islamabad"){ 
					time = 2;
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="islamabad" && city_d=="quetta"){
					time = 3; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="quetta" && city_d=="islamabad"){
					time = 3; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="islamabad" && city_d=="peshawar"){
					time = 1; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && city_d=="islamabad"){
					time = 1; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				} 
				if(city=="islamabad" && city_d=="karachi"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && city_d=="islamabad"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && city_d=="quetta"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="quetta" && city_d=="lahore"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && city_d=="peshawar"){
					time = 5; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && city_d=="lahore"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && city_d=="karachi"){
					time = 5; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && city_d=="lahore"){
					time = 5; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				} 
				if(city=="quetta" && city_d=="peshawar"){
					time = 3; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && city_d=="quetta"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="quetta" && city_d=="karachi"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && city_d=="quetta"){
					time = 4; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && city_d=="karachi"){
					time = 6; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && city_d=="peshawar"){
					time = 6; 
					t_amount = time * l_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>l_i;
					if(l_i>t_amount){
						check=1;
					}
				}    
				if(check == 1){
				if(type == "local"){
					F[i].setseats_l_l(city,id,type,city_d,n_u); 
				}
				if(type == "business"){ 
					F[i].setseats_b_l(city,id,type,city_d,n_u);
				} 
				}
				else{
					cout<<"not enough amount"<<endl;
				}
				l_amount = 10000;
				i_amount = 20000;
				check=0;
			} 
			if(i>=5 && i<10){
				cout<<"Countries ticket avaiable 1- australia 2- england 3- canada"<<endl;
//				cout<<"Enter your balance (bank amount) = ";
//				cin>>i_i;
//				if(i_i>i_amount){
				string coun_d;
				cout<<"Enter the name of country (destination) = ";
//				cin.ignore();
				getline(cin,coun_d);
				if(city=="islamabad" && coun_d=="australia"){
					time = 18; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && coun_d=="australia"){
					time = 15; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && coun_d=="australia"){
					time = 16; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && coun_d=="australia"){
					time = 14; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="quetta" && coun_d=="australia"){
					time = 20; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="islamabad" && coun_d=="england"){
					time = 8; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && coun_d=="england"){
					time = 12; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && coun_d=="england"){
					time = 18; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && coun_d=="england"){
					time = 10; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="quetta" && coun_d=="england"){
					time = 13; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="islamabad" && coun_d=="canada"){
					time = 21; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="lahore" && coun_d=="canada"){
					time = 22; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="karachi" && coun_d=="canada"){
					time = 18; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="peshawar" && coun_d=="canada"){
					time = 20; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}
				if(city=="quetta" && coun_d=="canada"){
					time = 19; 
					t_amount = time * i_amount;
					cout<<t_amount<<" required for this ticket"<<endl;
					cout<<"Enter your bank amount = ";
					cin>>i_i;
					if(i_i>t_amount){
						check=1;
					}
				}  
				if(check==1){
				for(int i=0 ; i<3 ; i++){
					if(ban[i] == coun_d){
						b=1;
						break;
					}
				}
				if(b==0){
					if(type == "local"){
						F[i].setseats_l_i(city,id,type,coun_d,n_u);
					}
					if(type == "business"){
						F[i].setseats_b_i(city,id,type,coun_d,n_u);
					}
				}
				else{
					cout<<"country flights is ban due to corona"<<endl;
				}  
				}
				else{
					cout<<"not enough amount"<<endl;
				}
				check=0;
				l_amount = 10000;
				i_amount = 20000;
//				}
			}
		}
};  

#endif
