#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <conio.h>
#include "Passenger.h" 
#include "Admin.h"
#include "Cities.h"
using namespace std;
 

int main(){
	cout<<"              ___"<<endl;
	cout<<"             |   |"<<endl;
	cout<<"             |   |"<<endl;
	cout<<"             |   |"<<endl;
	cout<<"  ___________|   |________"<<endl;
	cout<<" |                        \\\\"<<endl;
	cout<<" |           NPAFS         ||"<<endl;
	cout<<" |___________     ________//"<<endl;
	cout<<"             |   |"<<endl;
	cout<<"             |   |"<<endl;
	cout<<"             |   |"<<endl;
	cout<<"             |___|"<<endl; 
	cout<<endl<<endl;
	cout<<"NOTE: use small words only and do not use spaces in anything it will cause problem"<<endl;
	cout<<"Firstly we have to add passenger by register , then login as passenger , then register flight and then book a ticket"<<endl;
	cout<<"you will see menu first, where you use login setup, see flight Schedule, book a ticket according to your payment options"<<endl;
	cout<<endl<<endl;
	int want;
	cout<<"1- To see basic details\n2- Register as new passenger\n3- Register as admin\n4- To login as passenger\n5- To register flight\n6- Booking\n7- To exit\nEnter = ";
	cin>>want;
	int id;
	string n;
	string a;
	string l;
	string p;
	string c; 
	Passenger P;
	Admin A; 
	string f;
	string lg;
	string pass;
	string p_f;
	string s1;
	string s_1;
	int a1;
	int a_1;
	string s2;
	string s_2;
	string s3;
	string s_3;
	string s4;
	string s_4;
	string s5;
	string s_5;
	int a2=0;
	int a3=0;
	int a4=1;
	int a5=1;
	int a6=0;
	string l_id;
	int a7=0;
	int a8=0;
	int a9=0;
	string f_i;
	string d_c;
	cities C[5];
	int a10;
	int a11;
	string type;
	int flight_n;
	double age;
	C[0].setname("islamabad");
	C[1].setname("lahore");
	C[2].setname("quetta");
	C[3].setname("peshawar");
	C[4].setname("karachi");
	while(want!=7 && want<7){
		if(want==1){
			string line;
			string line2;
			string line3;
			string line4;
			string line5;
			string line6;
			string line7;
			string line8;
			string line9;
			string line10;
			ifstream print;
			cout<<endl;
			cout<<"\t\tFlight 1"<<endl<<endl;
			print.open("flight1.txt");
			while(getline(print,line)){
				cout<<line<<endl;
			}
			print.close();
			cout<<endl;
			cout<<"\t\tFlight 2"<<endl<<endl;
			ifstream print2;
			print2.open("flight2.txt");
			while(getline(print2,line2)){
				cout<<line2<<endl;
			}
			print2.close();
			cout<<endl;
			cout<<"\t\tFlight 3"<<endl<<endl;
			ifstream print3;
			print3.open("flight3.txt");
			while(getline(print3,line3)){
				cout<<line3<<endl;
			}
			print3.close();
			cout<<endl;
			cout<<"\t\tFlight 4"<<endl<<endl;
			ifstream print4;
			print4.open("flight4.txt");
			while(getline(print4,line4)){
				cout<<line4<<endl;
			}
			print4.close();
			cout<<endl;
			cout<<"\t\tFlight 5"<<endl<<endl;
			ifstream print5;
			print5.open("flight5.txt");
			while(getline(print5,line5)){
				cout<<line5<<endl;
			}
			print5.close();
			cout<<endl;
			cout<<"\t\tFlight 6"<<endl<<endl;
			ifstream print6;
			print6.open("flight6.txt");
			while(getline(print6,line6)){
				cout<<line6<<endl;
			}
			print6.close();
			cout<<endl; 
			cout<<"\t\tFlight 7"<<endl<<endl;
			ifstream print7;
			print7.open("flight7.txt");
			while(getline(print7,line7)){
				cout<<line7<<endl;
			}
			print7.close();
			cout<<endl;
			cout<<"\t\tFlight 8"<<endl<<endl;
			ifstream print8;
			print8.open("flight8.txt");
			while(getline(print8,line8)){
				cout<<line8<<endl;
			}
			print8.close();
			cout<<endl;  
			cout<<"\t\tFlight 9"<<endl<<endl;
			ifstream print9;
			print9.open("flight9.txt");
			while(getline(print9,line9)){
				cout<<line9<<endl;
			}
			print9.close(); 
			cout<<endl;
			cout<<"\t\tFlight 10"<<endl<<endl;
			ifstream print10;
			print10.open("flight10.txt");
			while(getline(print10,line10)){
				cout<<line10<<endl;
			}
			print10.close();
			cout<<endl; 
		}
		if(want==2){
				cout<<"Enter the name of passenger = ";
				cin.ignore();
				getline(cin,n);
				P.setname(n);
				cout<<"Enter the ID of passenger = ";
				cin>>id; 
				P.setid(id);
				cout<<"Enter the address of passenger = ";
				cin.ignore();
				getline(cin,a);
				P.setaddress(a);
				cout<<"Enter the login of passenger = ";
				getline(cin,l);
				P.setlogin(l);
				cout<<"Enter the password = ";
				getline(cin,p);
				P.setpassword(p);
				cout<<"Enter the cnic = ";
				getline(cin,c);
				P.setcnic(c);
				P.set_file();	    
		} 
		if(want==3){
				cout<<"Enter the name of admin = ";
				cin.ignore();
				getline(cin,n);
				A.setname(n);
				cout<<"Enter the ID of admin = ";
				cin>>id;
				A.setid(id);
				cout<<"Enter the address of admin = ";
				cin.ignore();
				getline(cin,a);
				A.setaddress(a);
				cout<<"Enter the login of admin = ";
				getline(cin,l);
				A.setlogin(l);
				cout<<"Enter the password = ";
				getline(cin,p);
				A.setpassword(p);
				A.set_file();
		}
		if(want==4){
			cout<<"Enter the login = ";
			cin.ignore();
			getline(cin,lg);
			ifstream in2;
			in2.open("logedinpassengers.txt");
			while(!in2.eof()){
				in2>>s_1>>a_1>>s_2>>s_3>>s_4>>s_5;
				if(lg==s_3){
					cout<<"your are already loged in"<<endl;
					a6=1;
					goto ahmad2;
				}
			}
			ahmad2:
			in2.close();
			if(a6!=1){
			ifstream ou;
			ou.open("passenger.txt");
			if(ou.is_open()){
				while(!ou.eof()){
				ou>>s1>>a1>>s2>>s3>>s4>>s5;
				if(s3==lg){
					cout<<"okay"<<endl;
					a2=1;
					goto ahmad;
				}
				a4++;
				} 
			ahmad:
			ou.close();
			}  
			
			ifstream inn;
			inn.open("passenger.txt");
				if(a2==1){
					cout<<"Enter the password = \n";
					char* pass = new char[30];
					string null;
					
					for(int i=0; 1; i++){
						
						char ch = getch();
						
						if(ch==13)
							break;
							
						pass[i] = ch;
						null = null + "*";
						cout<<null<<"\r";
							
						
						
					}
//					getline(cin,pass);
					while(!inn.eof()){
						inn>>s1>>a1>>s2>>s3>>s4>>s5;
						if(s4==pass && a5==a4){
							cout<<"your are loged in"<<endl;
							ofstream out2;
							out2.open("logedinpassengers.txt",ios::app);
							out2<<s1<<" "<<a1<<" "<<s2<<" "<<s3<<" "<<s4<<" "<<s5<<" "<<endl;
							out2.close();
							a3=1;
							goto ali;
						}
						a5++;
					}
				}
				else{
					cout<<"wrong login or not registered"<<endl;
				}
				ali:
					if(a3==0 && a2==1){
						cout<<"wrong password"<<endl;
					}
			a2=0;
			a3=0;
			a4=1;
			a5=1;
			}
			a6=0;
		}
		if(want==5){
			cout<<"Enter the login id = ";
			cin.ignore();
			getline(cin,l_id);
			
			ifstream in4;
			in4.open("registerforflight.txt");
			while(!in4.eof()){
				in4>>s_1>>a_1>>s_2>>s_3>>s_4>>s_5;
				if(l_id==s_3){
					cout<<"your are already registered"<<endl;
					a8=1;
					goto ahmad4;
				}
			}
			ahmad4:
			in4.close();
			if(a8!=1){
			ifstream in3;
			in3.open("logedinpassengers.txt");
			while(!in3.eof()){
				in3>>s_1>>a_1>>s_2>>s_3>>s_4>>s_5;
				if(l_id==s_3){
					cout<<"your are registered"<<endl;
					a7=1;
					goto ahmad3;
				}
			}
			ahmad3:
			in3.close();
			if(a7==0){
				cout<<"you are not registered for flight"<<endl;
			}
			else{
				ofstream out3;
				out3.open("registerforflight.txt",ios::app);
				out3<<s_1<<" "<<a_1<<" "<<s_2<<" "<<s_3<<" "<<s_4<<" "<<s_5<<" "<<endl;
				out3.close();
			}
			a7=0;
			}
			a8=0;
		}
		if(want==6){ 
			cout<<"Enter the login = ";
			cin.ignore();
			getline(cin,f_i);
			ifstream in5;
			in5.open("registerforflight.txt");
			while(!in5.eof()){
				in5>>s_1>>a_1>>s_2>>s_3>>s_4>>s_5;
				if(f_i==s_3){
					cout<<"your are registered"<<endl;
					a9=1;
					goto ahmad5;
				}
			} 
			ahmad5:
			in5.close();
			if(a9==0){
				cout<<"you are not registered for flight"<<endl;
			} 
			else{
				cout<<"Enter your age = ";
				cin>>age;
				if(age>18){
				cout<<"Enter the name of city of departure (islamabad,lohore,quetta,peshawar,karachi) = ";
				cin.ignore();
				getline(cin,d_c);
				for(int i=0 ; i<5 ; i++){
					if(C[i].return_name() == d_c){
						a10 = i;	
					}
				}
				cout<<"Enter the number of airport (1 , 2) = ";
				cin>>a11;
				C[a10].setid_airport(a11-1,a11);
				cout<<"Enter the flight number for local cities(1,2,3,4,5) and for international contries(6,7,8,9,10) = ";
				cin>>flight_n;
				cout<<"Enter the type of seat (local or business) = ";
				cin.ignore();
				getline(cin,type);
				C[a10].set_flights(a11-1,flight_n,type,f_i);
				}
				else{
					cout<<"your are not allowed to flight"<<endl;
				} 
			}
			a9=0;
		} 
		cout<<endl;
		cout<<"1- To see basic details\n2- Register as new passenger\n3- Register as admin\n4- login as passenger\n5- To register flight\n6- Booking\n7- To exit\nEnter = ";
		cin>>want;
	} 
	 
}   

